# Digital Skills Programme Website

Responsive one-page website for a 6-month project-based technology programme for secondary school students.

## Technologies
- HTML5
- CSS3
- Vanilla JavaScript

## Run locally
Open `index.html` in a browser.

## GitHub Pages
Upload `index.html`, `styles.css`, and `script.js` to a GitHub repository and enable GitHub Pages in repository settings.
